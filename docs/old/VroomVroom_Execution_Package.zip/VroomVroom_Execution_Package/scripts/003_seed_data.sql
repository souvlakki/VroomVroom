-- Optional Development Seed Data
-- Run only in development/test Supabase projects.

insert into public.organizations (name, description, contact_email)
values ('West Island FC', 'Demo youth soccer organization for Vroom Vroom.', 'demo@westislandfc.local')
on conflict (name) do nothing;