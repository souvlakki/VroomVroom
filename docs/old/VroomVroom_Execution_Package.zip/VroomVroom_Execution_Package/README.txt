# Vroom Vroom Execution Package

Follow the numbered Word documents in order.

Tool labels:
- ChatGPT = use this chat for planning, review, troubleshooting and prompt cleanup.
- Qwen = paste the included prompt into Qwen to generate code.
- Supabase = perform the steps inside the Supabase dashboard.

Important files:
- chapters/00_START_HERE_Index.docx
- scripts/001_initial_schema.sql
- scripts/002_rls_policies.sql
- scripts/003_seed_data.sql

Do not ask Qwen to build the whole app at once.
